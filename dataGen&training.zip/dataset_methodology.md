# Flipkart Grid 8.0 - Data Generation & Modeling Methodology

## 1. Dataset Generation Methodology

The synthetic data generation pipeline simulates a highly realistic e-commerce ecosystem consisting of Sellers, Products, Users, Orders, and Returns over a multi-year period (2022-2025). Rather than generating independent variables randomly, the ecosystem uses hierarchical, stateful simulation where entities interact with each other and generate natural temporal distributions and correlations.

The pipeline comprises 5 connected phases executed in sequential order by `run_pipeline.py`. Each phase stores its state and relies on the state of previously generated data:

1. **Sellers:** Bootstrapped first. Sellers are assigned to specific categories (e.g., Electronics, Fashion) and initialized with varying reputations, age, and natural return defect baselines based on what they sell.
2. **Products:** Products are assigned to categories with varying price brackets and `is_non_returnable` flags. The defect rate of a product heavily depends on its overarching category.
3. **Users:** User profiles are created with attributes like account age, email verification, and shared device markers.
4. **Orders:** A realistic time-series distribution of orders is generated across the years. The probability of a user ordering depends on their account age. Order volume exhibits seasonal variations, and product choices are logically constrained (users buy from products/sellers).
5. **Returns (Fraud vs. Legitimate):** Out of all generated orders, a specific subset is selected as returned items. The system assigns a `fraud` or `legitimate` label mathematically. 
   - A base "fraud score" is calculated using additive conditions (e.g., new unverified accounts, high-value electronics, weekend returns, mismatched return reasons).
   - Random noise is injected using a binomial distribution and a sigmoid probability curve. This perfectly simulates realistic datasets where fraud is not 100% deterministic or linearly separable.

## 2. Detailed Parameters and Distributions

All base parameters are centralized in `data_gen/config.py` to allow easy tweaks without editing generation logic.

### Global Configuration
- **Time Window:** Jan 2022 – Jun 2025.
- **Entity Counts:** 500 Sellers, 1,000 Products, 6,000 Users, ~25,000 Total Orders, generating exactly 10,000 Return Requests.
- **Fraud Target Ratio:** ~40% of the return dataset is intentionally designed as fraud.

### User & Buyer Profiles
- **Account Age:** Modeled using a Right-skewed Lognormal distribution (most users are 90-730 days old, max limit 2,500 days).
- **Email Verification:** 95% for accounts older than 120 days, dropping to 80% for newer accounts.
- **Shared Device:** 6% for general population, but boosted to 16% for new/unverified accounts.
- **Buyer Price Affinities:** Users are assigned wealth brackets: Budget (40%, ₹80–₹4k), Mid (40%, ₹1k–₹18k), Premium (20%, ₹8k–₹200k).
- **Category Affinities:** Users are assigned shopping traits: Focused (30%, buys from 1-2 categories), Moderate (50%, 3-5 categories), Explorer (20%, 6-10 categories).

### User Fraud Behaviors & Order Volumes
Instead of randomly assigning orders, users get assigned a behavior type which dictates their ordering volume and return probability:
- **Legitimate:** 60% of users. Averages 4 orders, ~22% return rate.
- **Wardrober:** 10% of users. Averages 7.5 orders, ~75% return rate.
- **Serial Returner:** 10% of users. Averages 9 orders, ~82% return rate.
- **Empty Box (Fraud):** 8% of users. Averages 7 orders, ~72% return rate.
- **Item Swap (Fraud):** 7% of users. Averages 6 orders, ~68% return rate.
- **Seller-Buyer Collusion:** 5% of users. Averages 8 orders, ~72% return rate.

### Products & Categories
- **Price Distribution:** Unique lognormal distributions per category. Electronics (median ~₹8,100), Appliances (median ~₹13,360), Grocery (median ~₹148). 
- **Stock & Reviews:** Review counts and Stock Keeping Units (SKUs) are heavily right-skewed lognormal distributions (few blockbuster products, many niche ones).
- **Category Policies:** Grocery is 95% non-returnable (0-day window). Electronics is 10-day window, Clothing/Footwear is 30-day window.
- **Defect Rates:** Fraction of products mathematically allowed to have legitimate defects varies by category (e.g., Electronics 4%, Grocery 8%, Books 1%).

### Sellers
- **Seller Account Age:** Right-skewed lognormal (mu=6.4, sigma=0.85).
- **Seller Ratings:** Drawn from a Beta distribution. Veteran sellers (>180d) are skewed heavily towards 3.5–5 stars, while new sellers are heavily skewed towards 1.5–3.5 stars.
- **Seller Typology:** Sellers are hard-assigned to specific categories (e.g., "Fashion Lifestyle" sellers only sell Clothing/Footwear/Beauty, "Tech" sellers only sell Electronics/Appliances) to ensure logical purchase mappings.

## 3. Running the Pipeline

### Step 1: Generate the Synthetic Dataset
Run the data generator to construct all CSVs. This will sequentially build sellers, products, users, orders, and returns, outputting them into the `data_gen/output/` directory.

```bash
python data_gen/run_pipeline.py
```

### Step 2: Feature Engineering & Model Training
Once the raw CSVs are generated, run the model pipeline. This script merges the raw CSVs, performs complex temporal feature engineering (rolling averages, past behavior aggregates), chronologically splits the dataset (First 80% Train, Last 20% Test), trains a LightGBM classifier, outputs the evaluation metrics, and saves the final resources.

```bash
python model_pipeline.py
```

**Artifacts Generated by the Pipeline:**
- `feature_importance.png`: Visualizes the most predictive features.
- `data_gen/output/train_dataset.csv`: Final engineered training data.
- `data_gen/output/test_dataset.csv`: Final engineered testing data.
- `data_gen/output/lgbm_model.pkl`: The trained LightGBM model saved via `joblib`.
