# Returns Policy — Books, Sports & Fitness Equipment, Auto Accessories

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Applicable Categories

- Books (All books)
- Sports Equipment (Racquet, ball, support, gloves, bags, etc.)
- Exercise & Fitness Equipment (Home Gym combos, dumbbell, etc.)
- Auto Accessories — Car and Bike accessories (helmets, car kit, media players, etc.)

## Return Window

7 days

## Action

Replacement only.

## Conditions

Free replacement is provided within 7 days if the product is delivered in defective/damaged condition, or is different from the item ordered.

The product must be kept intact, with original accessories, user manual, and warranty cards, in the original packaging, at the time of return.
