# Cancellation Policy

*Source: Flipkart.com Order Cancellation and Return Policy (scraped)*

## Cancellation Window

The customer can choose to cancel an order any time before it's dispatched. The order cannot be canceled once it's out for delivery. However, the customer may choose to reject it at the doorstep.

The time window for cancellation varies based on different categories, and the order cannot be canceled once the specified time has passed. The details about the time window mentioned on the product page or order confirmation page are considered final.

## Cancellation Fees

In some cases, the customer may not be allowed to cancel the order for free after the specified time window, and a cancellation fee will be charged.

## Seller-Initiated Cancellation

In case of any cancellation from the seller due to unforeseen circumstances, a full refund will be initiated for prepaid orders.

Flipkart reserves the right to accept the cancellation of any order, and to waive off or modify the time window or cancellation fee from time to time.

## Notes

Flipkart's return, cancellation, and refund policies may be subject to additional reasonable terms and conditions, communicated periodically through the Platform's push notifications or other communication methods.
