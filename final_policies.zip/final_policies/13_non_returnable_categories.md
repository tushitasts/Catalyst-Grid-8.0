# Returns Policy — Non-Returnable Categories

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## General Rule

Some products across the categories listed in this corpus are not returnable, due to their nature or other reasons. For all products, the policy stated on the specific product page shall prevail over this general document.

## Source Limitation

The scraped general returns policy page refers readers to a separate, dedicated list of non-returnable products ("You can view the complete list of non-returnable products here") rather than enumerating that list on the page itself. That linked list was not part of the scraped source document and is therefore **not included in this RAG corpus.**

## Known Non-Returnable Items (from within the scraped policy text)

The following specific non-returnable items *are* stated directly in the scraped policy and can be relied upon:

- **All Wind Instruments** (Harmonicas, Flutes, etc.) — non-returnable due to hygiene and personal wellness reasons, except for a free replacement if delivered damaged/defective or different from the item ordered (see the Toys/Stationery/Musical Instruments document).

## System Implication

For any product category not explicitly covered by a return-window document in this corpus, and not confirmed as returnable elsewhere in this corpus, the system should **not assume returnability**. Treat an unmatched or ambiguous category as a policy-ambiguity case and Escalate to Human, per the Escalation Matrix in the AI Decision Guidelines — do not default to Auto-Approve or Auto-Reject based on absence of a matching policy chunk.
