# Returns Policy — Part 3: General Rules for a Successful Return

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 3*

## Replacement Not Possible

In certain cases where the seller is unable to process a replacement for any reason whatsoever, a refund will be given instead.

## Missing/Damaged/Defective Accessory

Where a product accessory is found missing, damaged, or defective, the seller may either:
- process a replacement of that particular accessory, or
- issue an eGV (e-gift voucher) for an amount equivalent to the price of the accessory, at the seller's discretion.

## Open Box Delivery

During open-box deliveries, if the customer receives a different or damaged product while accepting the order, a refund is given (on-the-spot refunds for cash-on-delivery orders).

Once an open-box delivery has been **accepted**, no further return request will be processed — except for manufacturing defects. In such cases, the category-specific replacement/return conditions elsewhere in this corpus apply.

## Installation by Authorized Personnel

For products where installation is provided by Flipkart's service partners, the customer should not open the product packaging themselves. Flipkart-authorized personnel handle unboxing and installation.

## Furniture-Specific Repair Rule

For Furniture, product-related issues are checked by authorized service personnel (free of cost) and the seller will first attempt to resolve the issue by replacing the faulty/defective part. A full replacement is only provided if the service personnel determines that replacing the faulty/defective part will not resolve the issue.
