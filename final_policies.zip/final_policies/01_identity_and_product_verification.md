# Product Identity Verification Policy

## Applicability

This policy applies to all return and replacement requests where the product carries a unique identifier — IMEI, serial number, barcode, article number, or product registration number.

## Verification Requirement

The identifier on the product being returned must match the identifier recorded at the time of original delivery. This is consistent with the "Correct Product" condition under the general Returns Policy, which requires that IMEI, name, image, brand, serial number, and barcode match, and that the MRP tag remain undetached and clearly visible.

## Decision Guidance

| Verification Outcome | Action |
|---|---|
| Identifier matches original delivery record | Continue standard return review |
| Identifier cannot be confirmed (missing scan, illegible tag, no serial captured at dispatch) | Escalate to Human for manual verification |
| Identifier confirmed mismatched (different IMEI/serial/barcode than what was shipped) | Not eligible for return — Reject |

## Notes

- A confirmed mismatch is treated as a potential item-swap case and should be logged accordingly.
- Absence of a capturable identifier at time of purchase (e.g., category does not carry one) does not itself trigger escalation — this clause only applies where such an identifier exists and was recorded.
