# Returns Policy — Overview and Precedence

*Source: Flipkart.com Order Cancellation and Return Policy (scraped)*

## What This Policy Covers

Returns is a scheme provided by respective sellers directly, under which the option of exchange, replacement, and/or refund is offered to the customer. Not all products listed under a particular category have the same returns policy.

## Precedence Rule

For all products, the returns/replacement policy provided on the specific product page shall prevail over this general returns policy. Customers should refer to the respective item's applicable return/replacement policy on the product page for any exceptions to the general policy and category table.

## Structure

The return policy is divided into three parts:

1. **Part 1** — Category, Return Window, and Actions Possible (see the category-specific documents in this corpus)
2. **Part 2** — Returns Pick-Up and Processing conditions
3. **Part 3** — General Rules for a successful return

## Return Restrictions

Flipkart holds the right to restrict the number of returns created per order unit, following evaluation of the product/order defect by Flipkart's authorized representative.
