# Returns Policy — Grocery

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Applicable Categories and Windows

| Sub-Category | Return Window | Action |
|---|---|---|
| Grocery (Excluding Minutes) — Dairy, Bakery, Fruits and Vegetables | 2 days | Refund only |
| Grocery (Excluding Minutes) — Remaining items (pulses, atta, edible goods, etc.) | 7 days | Refund only |

## Notes

This document covers marketplace Grocery only, not the Minutes/Hyperlocal quick-commerce grocery flow, which is governed by a separate policy.
