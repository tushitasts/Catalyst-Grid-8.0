# Packaging and Accessory Completeness Policy

## Applicability

This policy applies to all returns and elaborates on the "Complete Product" and "Undamaged Packaging" conditions in the general Returns Policy.

## Packaging Requirement

The product's original packaging, including labels, barcodes, and any manufacturer seals, must be present and undamaged. Packaging condition is checked at the time of pick-up, consistent with Part 2 of the general Returns Policy.

Where original packaging is missing or damaged, the return is escalated for review rather than auto-rejected, unless the applicable category or product-page policy explicitly states otherwise.

## Accessory Requirement

All in-the-box accessories, freebies, and combo items present at the time of delivery must be returned with the product. This includes items such as chargers, remote controls, manuals, and instruction booklets, consistent with the general Returns Policy.

## Decision Guidance

| Condition | Action |
|---|---|
| Packaging and all accessories present and undamaged | Continue standard review |
| Missing packaging only, category policy silent on exception | Escalate to Human |
| Minor accessory missing (e.g., manual, warranty card) | Eligible for partial resolution — Replacement or partial refund at seller's discretion, per general Returns Policy |
| Major accessory missing (e.g., charger for an electronic device, a component required for product function) | Escalate to Human |

## Notes

Field executives are entitled to refuse pick-up if packaging or accessory conditions are not met, per Part 2 of the general Returns Policy. This should be treated as supporting evidence, not as an automatic fraud determination.
