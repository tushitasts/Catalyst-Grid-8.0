# Returns Policy — "No Questions Asked"

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Return Window

10 days

## Action

Refund or Replacement.

## What This Policy Means

This policy enables easy product return requests for customers through the Platform, **subject to product validations at the time of pick-up and fraud prevention mechanisms.** "No Questions Asked" does not mean fraud checks are bypassed — it means the customer is not required to justify the return with a detailed reason to be eligible, provided validations pass.

## Applicability

This policy applies only if the product was purchased when this policy was applicable to that product. If not, the policy in effect at the time of purchase applies instead.

A customer may seek only a **one-time replacement** under this policy, subject to other terms herein.

## Exceptions

The following claim types are **not** covered under this policy and instead fall under the standard category-specific policy and its corresponding validation process:

a. Product undelivered
b. Product/accessories missing
c. Wrong product/accessories delivered

## System Implication

Because this policy is explicitly paired with "fraud prevention mechanisms," a "No Questions Asked" return should still pass through the Data Agent and Risk Agent — it is not exempt from fraud scoring. The relaxed requirement is on the *stated reason*, not on the underlying risk assessment.
