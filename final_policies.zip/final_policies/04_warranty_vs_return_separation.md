# Warranty vs. Return Claim Separation Policy

## Applicability

This policy applies to products covered by manufacturer or brand warranty, particularly Mobiles, Electronics, and Large Appliances as categorized in the general Returns Policy.

## Principle

A warranty claim is distinct from a return claim. The Returns Policy governs eligibility for refund, replacement, or exchange within the stated returns window. Once the returns window has closed, or where the applicable category is designated "Replacement/Repair only" via brand service centre, product issues are handled under the manufacturer's warranty terms rather than the returns process.

This is consistent with the general Returns Policy's treatment of brands such as Apple, Google, Samsung, and other listed manufacturers, where the final decision on replacement of a defective device rests with the seller or brand, and the customer is directed to an authorized service centre once the diagnostic window has elapsed.

## Decision Guidance

| Condition | Action |
|---|---|
| Return request within the stated returns window, defect confirmed | Process under standard Returns Policy (refund/replacement per category) |
| Return request outside returns window, product covered by active warranty | Not a return — direct to authorized brand service centre |
| Ambiguous — unclear whether issue is a returns-window defect or a warranty-only issue | Escalate to Human |

## Notes

Do not auto-reject a request solely because the returns window has closed if the product is warranty-eligible; route it to the correct channel rather than terminating it.
