# Returns Policy — Medicine

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Applicable Categories

- Medicine (Allopathy & Homeopathy)

## Return Window

2 days

## Action

Refund.
