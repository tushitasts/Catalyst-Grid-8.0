# Returns Policy — Lifestyle (Apparel, Accessories, Winterwear)

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Applicable Categories

- Lifestyle: Watch, T-Shirt, Footwear, Sari, Short, Dress, Kid's (Capri, Shorts & Tops), Men's (Ethnic Wear, Shirt, Formals, Jeans, Clothing Accessory), Women's (Ethnic Wear, Fabric, Blouse, Jean, Skirt, Trousers, Bra), Bags, Raincoat, Sunglass, Belt, Frame, Backpack, Suitcase, Luggage, etc.
- Lifestyle: Jewellery, Footwear Accessories, Travel Accessories, Watch Accessories, etc.
- Lifestyle: WinterWear (sweatshirt, jacket, sweater, cardigan, kids_thermal, pullover, windcheater, track_suit, thermal, shawl, track_top, glove, muffler, scarf, blazer, uniform_sweatshirt, uniform_blazer, kids_muffler, kids_mitten, shrug, poncho, uniform_sweater, cap, waistcoat, leg_warmer, legging, elder_halloween_costume)

## Return Window

10 days

## Action

Refund, Replacement, or Exchange.

## Conditions

No additional category-specific conditions beyond the general Part 2 (pick-up) and Part 3 (general rules) requirements. The "Unused Product," "Undamaged Product," and "Undamaged Packaging" conditions apply with particular relevance to this category, given its high exposure to wardrobing-style misuse.
