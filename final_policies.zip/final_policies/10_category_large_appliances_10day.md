# Returns Policy — Large Appliances (Non-Flagship) & Select Small Appliances

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Applicable Categories

- Furniture, Large Appliances **except** the flagship-brand list (Vu, LG, Godrej, Haier, IFB, Hindware, Glen, Faber, AGARO, Voltas, BOSCH, Pureit, PHILIPS, HAVELLS, Elica, BAJAJ, Kenstar, Eureka Forbes Aquasure from Aquaguard, Aquaguard, LIVPURE, EUREKA FORBES, Crompton, Hindware Snowcrest, Hindware Calisto, Eurodomo, Symphony, Hindware Atlantic, ONIDA, CANDY, Llyod, Voltas Beko, realme, Daikin, CARRIER, Mi, Midea, Whirlpool, Blue Star, Panasonic, Morphy Richards, iFFALCON, Hisense, TCL, TOSHIBA, Hitachi, Rockwell, KENT — see separate flagship service-centre document)
- Rest of Small Home Appliances — Chimney, Water Purifier, Fan, Geyser only

## Return Window

10 days

## Action

Replacement only.

## Conditions

For products requiring installation, returns are eligible only when installed by the brand's authorized personnel.

Flipkart may troubleshoot the product through online tools, over the phone, and/or an in-person technical visit.

- If a defect is determined within the Returns Window, a replacement of the same model is provided at no additional cost.
- If no defect is confirmed, or the issue is not diagnosed within 10 days of delivery or installation (wherever applicable), the customer will be directed to a brand service centre.
- In any case, only one replacement shall be provided.
