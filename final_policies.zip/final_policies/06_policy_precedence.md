# Policy Precedence and Conflict Resolution

## Principle

Where more than one policy provision appears applicable to a given return request, the following precedence applies, consistent with the general Returns Policy's statement that product-page policy prevails over the general policy:

1. The return/replacement policy stated on the specific product page for the item in question
2. The category-specific policy under the general Returns Policy (return window, action, and conditions table)
3. General policy provisions not specific to a category (e.g., Part 2 pick-up conditions, Part 3 general rules)

## Decision Guidance

| Condition | Action |
|---|---|
| A single, clearly applicable category or product-page policy governs the request | Apply that policy |
| Two policies conflict and precedence resolves the conflict per the order above | Apply the higher-precedence policy |
| Ambiguity remains even after applying precedence (e.g., product could plausibly fall under two categories) | Escalate to Human |

## Notes

This clause exists to prevent the system from silently picking whichever retrieved policy chunk is most favorable to a given verdict. Precedence must be applied explicitly and stated in the justification trail.
