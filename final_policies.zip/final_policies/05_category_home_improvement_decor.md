# Returns Policy — Home Improvement, Décor, Furnishing, Household Items

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Applicable Categories

- Home: Home Improvement Tools, Household Items, Home Décor, Furnishing

## Return Window

7 days

## Action

Refund or Replacement.
