# Returns Policy — Standard Mobiles, Electronics & Small Home Appliances

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Applicable Categories

- All Mobiles **except** Apple, Google, Motorola, Infinix, Redmi, MI, Vivo, POCO, Realme, Samsung phones
- Electronics **except** Apple/Beats, Google, Realme, Samsung, JBL & Infinity, Epson, HP, Dell, Canon, MI, Dizo products (Tablets, Laptops, Smart Watches)
- All Small Home Appliances **except** Chimney, Water Purifier, Fan, Geyser
- Furniture — Hammock Swing & Stool

*Note: the flagship brands excluded above are covered under a separate service-centre-only policy — see the corresponding document in this corpus.*

## Return Window

7 days

## Action

Replacement only.

## Conditions

Flipkart may troubleshoot the product through online tools, over the phone, and/or an in-person technical visit to help resolve issues.

- If a defect is determined within the Returns Window, a replacement of the same model is provided at no additional cost.
- If no defect is confirmed, or the issue is not diagnosed within 7 days of delivery, the customer will be directed to a brand service centre for any subsequent issues.
- In any case, only one replacement shall be provided.
