# Returns Policy — Part 2: Pick-Up and Processing Conditions

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 2*

## Address Changes

If a customer wants item(s) picked up from a different address than the delivery address, the address can only be changed if pick-up service is available at the new address.

## Conditions Checked at Pick-Up

During pick-up, the product is checked against the following conditions:

| Condition | Requirement |
|---|---|
| **Correct Product** | IMEI/name/image/brand/serial number/article number/barcode should match the original order, and the MRP tag should be undetached and clearly visible. |
| **Complete Product** | All in-the-box accessories (remote control, starter kits, instruction manuals, chargers, headphones, etc.), freebies, and combos (if any) should be present. |
| **Unused Product** | The product should be unused, unwashed, unsoiled, without any stains, and with non-tampered quality-check seals/return tags/warranty seals (wherever applicable). Before returning a Mobile/Laptop/Tablet, the device must be formatted and Screen Lock (PIN, Pattern, or Fingerprint) disabled. iCloud lock must be disabled for Apple devices. |
| **Undamaged Product** | The product (including SIM trays, charging port, headphone port, back panel, etc.) should be undamaged and without scratches, dents, tears, or holes. |
| **Undamaged Packaging** | The product's original packaging/box should be undamaged. |

## Enforcement

The field executive will refuse to accept the return if any of the above conditions are not met.

## Refund Timing

For products where a refund is due, the refund is processed once the returned product has been received by the seller.
