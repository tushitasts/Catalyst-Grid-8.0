# Returns Policy — Refurbished Products

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Return Window

7 days

## Action

Replacement only.

## Conditions

Flipkart may troubleshoot the product through online tools, over the phone, and/or an in-person technical visit to help resolve issues.

If a defect is determined within the Returns Window, a replacement of the same model is provided at no additional cost. If no defect is confirmed, or the issue is not diagnosed within 7 days of delivery, the customer will be directed to the warranty partner to resolve any subsequent issues.
