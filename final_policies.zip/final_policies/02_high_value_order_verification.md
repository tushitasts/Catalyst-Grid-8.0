# High-Value Order Return Policy

## Applicability

This policy applies to return or replacement requests where the original order value exceeds ₹50,000, in addition to the category-specific return window and conditions described in the general Returns Policy.

## Additional Requirements

For high-value orders, the following supporting evidence is required before a return can be processed:

- Product photographs showing current condition
- Invoice verification against the order record
- Confirmation of customer identity consistent with the account and delivery record

## Decision Guidance

High-value returns are not auto-approved regardless of stated reason. They follow the category return window and condition requirements set out in the general Returns Policy, with the following additional trigger:

| Condition | Action |
|---|---|
| Order value > ₹50,000 and supporting evidence is complete and consistent | Continue standard review under applicable category policy |
| Order value > ₹50,000 and supporting evidence is incomplete, inconsistent, or unverifiable | Escalate to Human |

## Notes

This clause does not override category-specific eligibility (e.g., non-returnable categories remain non-returnable regardless of value). It adds a verification step on top of category policy for high-value orders specifically.
