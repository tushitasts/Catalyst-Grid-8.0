# Evidence and Reason Consistency Policy

## Applicability

This policy applies to all return requests where the customer provides a free-text reason and, optionally, supporting images.

## Requirement

The stated reason for return must be consistent with:

- The product category and its typical use
- The order and delivery timeline
- Any uploaded supporting evidence (images or documentation)

Where a customer submits supporting images, the image should reasonably correspond to the product ordered and should support the claimed condition or defect described in the return reason.

## Decision Guidance

| Condition | Action |
|---|---|
| Reason, category, timeline, and evidence (if provided) are consistent | Continue standard review |
| Minor ambiguity in stated reason, no contradiction with other evidence | Continue standard review; may inform risk assessment |
| Clear contradiction between stated reason and product category, timeline, or evidence | Escalate to Human |
| Evidence provided is unreadable, incomplete, or does not correspond to the product in question | Request additional evidence before proceeding; if unresolved, Escalate to Human |

## Notes

This clause establishes the consistency requirement itself. Determining *how* a specific case is assessed for consistency (e.g., automated plausibility scoring) is an implementation detail of the review process and is not dictated by this policy — this document only defines what must hold true for a request to proceed without escalation.
