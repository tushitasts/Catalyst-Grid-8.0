# Returns Policy — Furniture, Pet Supplies & Rest of Home

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Applicable Categories

- Furniture
- Home: Pet Supplies & Rest of Home (Except Home Décor, Furnishing, Home Improvement Tools, Household Items — see separate document for those)

## Return Window

10 days

## Action

Refund or Replacement.

## Installation-Dependent Conditions

For products requiring installation, returns are eligible only when such products are installed by the brand's authorized personnel.

In order to help resolve issues, Flipkart may troubleshoot the product through online tools, over the phone, and/or through an in-person technical visit.

- If a defect is determined within the Returns Window, a refund/replacement of the same product is provided at no additional cost.
- If no defect is confirmed, or the issue is not diagnosed within 10 days of delivery or installation (wherever applicable), the customer will be directed to a brand service centre to resolve any subsequent issues.
- In any case, only one replacement shall be provided.
