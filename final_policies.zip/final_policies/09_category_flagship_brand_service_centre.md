# Returns Policy — Flagship Mobile, Electronics & Appliance Brands (Service Centre Only)

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Applicable Categories

- **Mobile:** Apple, Google, Motorola, Infinix, Redmi, MI, Vivo, POCO, Realme, Samsung phones
- **Electronics:** Acer, AMKETTE, Apple/Beats, Bose, Brother, Canon, Compaq, CREATIVE, DELL, DIZO, Epson, Google, GoPro, GOVO, HP, INFINITY, JBL, Lenovo, LG, Lifelong, Mi, MOTOROLA, Nothing, OnePlus, OPPO, Panasonic, PHILIPS, Realme, REDMI, SAMSUNG, Sansui, Seagate, Sonos, SONY, Thomson, Total, Xiaomi products (Tablets, Laptops, Smart Watches, Headphones, Speakers)
- **Large Appliances:** Vu, LG, Godrej, Haier, IFB, Hindware, Glen, Faber, AGARO, Voltas, BOSCH, Pureit, PHILIPS, HAVELLS, Elica, BAJAJ, Kenstar, Eureka Forbes Aquasure from Aquaguard, Aquaguard, LIVPURE, EUREKA FORBES, Crompton, Hindware Snowcrest, Hindware Calisto, Eurodomo, Symphony, Hindware Atlantic, ONIDA, CANDY, Llyod, Voltas Beko, realme, Daikin, CARRIER, Mi, Midea, Whirlpool, Blue Star, Panasonic, Morphy Richards, iFFALCON, Hisense, TCL, TOSHIBA, Hitachi, Rockwell, KENT

## Return Window / Action

7 Days — Service Centre Replacement/Repair only. This is **not** a standard Flipkart-processed return.

## Conditions

Brand assistance for device-related issues is subject to the brand's own warranty guidelines and service policies. Customers should reach out to the nearest brand-authorized service centre.

Flipkart is an online marketplace; the final decision on replacement of a defective device for these brands rests with the seller/brand, not Flipkart directly.

For Samsung specifically: in case of DOA (Dead on Arrival) approved by the brand, the customer must share the certificate of approval with Flipkart customer support to process the complaint.

For any other issues, customers may contact Flipkart's 24×7 Customer Care.

## System Implication

Return requests for these brands should generally route to **Escalate** or an informational deflection rather than a standard Auto-Approve/Auto-Reject flow, since Flipkart itself does not have final authority over the outcome.
