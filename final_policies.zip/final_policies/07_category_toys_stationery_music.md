# Returns Policy — Toys, Stationery, Musical Instruments

*Source: Flipkart.com Order Cancellation and Return Policy (scraped), Part 1*

## Applicable Categories

- Toys (Remote controlled toys, Learning toys, Stuffed toys, etc.)
- Stationery (Pens, Diary notebooks, Calculators, etc.)
- Musical Instruments (Microphones & Accessories, Guitars, Violins, etc.)

## Return Window

7 days

## Action

Replacement only.

## Conditions

Free replacement is provided within 7 days if the product is delivered in defective/damaged condition, or is different from the item ordered.

The product must be kept intact, with original accessories, user manual, and warranty cards, in the original packaging, at the time of return.

## Category-Specific Exception: Wind Instruments

All Wind Instruments (Harmonicas, Flutes, etc.) are **non-returnable** due to hygiene and personal wellness reasons.

Exception to the exception: if these products are delivered in damaged/defective condition, or different from the ordered item, a free replacement will still be provided.
